const { bot, bing, dall3 } = require('../lib/')
const config = require('../config')
bot(
  {
    pattern: 'bing ?(.*)',
    fromMe: true,
    desc: 'bing ai',
    type: 'ai',
  },
  async (message, match) => {
    if (!config.BING_COOKIE)
      return await message.send(
        `Harap tetapkan cookie bing, masuk ke bing.com/chat, gunakan obrolan AI bing sekali, lalu salin cookie.`
      )
    match = match || message.reply_message.text
    if (!match) return await message.send('*Example :* bing Hi')
    await message.send(
      {
        text: '⏳',
        key: message.message.key,
      },
      {},
      'react'
    )
    const res = await bing(match)
    await message.send(
      {
        text: '✅',
        key: message.message.key,
      },
      {},
      'react'
    )
    return await message.send(res, { quoted: message.data })
  }
)

bot(
  {
    pattern: 'dale ?(.*)',
    fromMe: true,
    desc: 'bing image creator',
    type: 'ai',
  },
  async (message, match) => {
    if (!config.BING_COOKIE)
      return await message.send(
        `Harap tetapkan cookie bing, masuk ke https://bing.com/images/create, gunakan Bing Image Creator sekali, lalu salin cookie.`
      )
    if (!match)
      return await message.send(
        '*Contoh :* Buat ilusi 3D untuk foto profil WhatsApp yang memperlihatkan seorang anak laki-laki dengan kemeja putih duduk santai di Sofa kerajaan. Mengenakan sepatu kets putih, kaos hitam, dan kacamata hitam, ia melihat ke depan. .'
      )
    await message.send(
      {
        text: '⏳',
        key: message.message.key,
      },
      {},
      'react'
    )
    const res = await dall3(match)
    await message.send(
      {
        text: '✅',
        key: message.message.key,
      },
      {},
      'react'
    )
    return await message.sendFromUrl(res.data)
  }
)
